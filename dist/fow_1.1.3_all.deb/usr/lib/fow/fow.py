#!/usr/bin/env python3.5
import main
import sys
#print('sys.argv=' + str(sys.argv))
main.fow(sys.argv)
