#!/usr/bin/env python3.5
import sys

import main

main.fow(sys.argv)
