#!/usr/bin/env python3
import sys

import main

main.fow(sys.argv)
